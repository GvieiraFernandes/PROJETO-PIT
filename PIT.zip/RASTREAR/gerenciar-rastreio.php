<?php
	$pdo = new PDO ("mysql: host=localhost; dbname=vita4u","root", "");
?>
<form method="post">
	<label for="rastreio">Código de Rastreio:</label>
	<input type="text" name="rastreio" required>
	
	<label for="status">Status da Remessa:</label>
	<select name="status">
		<option value="1">Remessa Recebido</option>
		<option value="2">Remessa em Transferência para Região</option>
		<option value="3">Remessa a Destino</option>
		<option value="4">Remessa Entregue</option>
		<option value="5">Remessa Em Atraso</option>
		<option value="6">Remessa Agendada</option>
		<option value="7">Remessa Cancelada</option>
		<option value="8">Remessa Devolvida</option>
	</select>

	<label for="tempo">Horário da Chegada:</label>
	<input type="time" name="tempo" value="00:00"> <!-- Adicione um campo para o tempo de entrega -->
	
	<button name="atualizar" value="atualizar">Atualizar Remessa</button>
</form>

<?php
if(isset($_POST['atualizar'])):
    $pedido = '123';
    $codigo = filter_input(INPUT_POST, 'rastreio', FILTER_DEFAULT);
    $status = filter_input(INPUT_POST, 'status', FILTER_DEFAULT);
    $hora_chegada = $_POST['tempo']; // Obter o valor do campo de hora

    $data = date('Y-m-d H:i:s', strtotime($hora_chegada)); // Combinar data com a hora de chegada

    $inseri = $pdo->prepare("INSERT INTO si_rastreio (rastreio_pedido, rastreio_codigo, rastreio_data, rastreio_status, tempo_entrega) VALUES (:pedido, :code, :data, :stat, :tempo)");
    $inseri->bindValue(':pedido', $pedido);
    $inseri->bindValue(':code', $codigo);
    $inseri->bindValue(':data', $data);
    $inseri->bindValue(':stat', $status);
    $inseri->bindValue(':tempo', $hora_chegada); // Inclua o tempo de entrega
    $inseri->execute();

    if($inseri):
        echo 'O status do pedido: <b>'.$codigo.' foi alterado com sucesso</b><br>';
    else:
        echo 'Não pode ser atualizado remessa para este código de rastreio';
    endif;
endif;

?>
