<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>AVALIAÇÃO</title>
		<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="avaliar.css">
		<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&family=REM:wght@100;200;300;400;500;600;800;900&display=swap" rel="stylesheet">
	</head>
	<body>
    <header>
        <div class="flex-1">

            <h1 id="logo">VITA4U</h1>
            <ul id="cabecalho" class="links-nav">
                    <li>Entregador</li>
                    <li>Restaurante</li>
                    <li>Usuario</li>
                </ul>
        </div>
        <nav class="navbar">
                <ul id="cabecalho-2" class="links-nav">
                    <li>Home</li>
                    <li>Contato</li>
                </ul>
           

            <div id="div-1" class="links-btn">
                <img src="carrinho.png" alt="">
                <img src="personagem.png" alt="">
            </div>
        </div>
    </header>


    
    <div id="bloco">
    <h1 id="titulo">Ambrozini Saúdavel</h1>
    <img id="restaurante" src="restaurante.png" alt="">
    <button id="avaliar"><img id="star" src="Star.png" alt="">                              3.7<br>Avalie aqui</button>
</div>





<div id="b1" >

<h1 id="titulo2">Dê o seu Feedback</h1>

<p id="txt-1">Oque você achou da comida?</p>


<div>
	

		<span id="teste"> <?php if(isset($_SESSION['msg']))
			echo $_SESSION['msg']."<br><br>";
			unset($_SESSION['msg']); ?></span> 
		
		
		<form id="estrela" method="POST" action="processa.php" enctype="multipart/form-data">
			<div class="estrelas">
				<input type="radio" id="vazio" name="estrela" value="" checked>
				
				<label for="estrela_um"><i class="fa"></i></label>
				<input type="radio" id="estrela_um" name="estrela" value="1">
				
				<label for="estrela_dois"><i class="fa"></i></label>
				<input type="radio" id="estrela_dois" name="estrela" value="2">
				
				<label for="estrela_tres"><i class="fa"></i></label>
				<input type="radio" id="estrela_tres" name="estrela" value="3">
				
				<label for="estrela_quatro"><i class="fa"></i></label>
				<input type="radio" id="estrela_quatro" name="estrela" value="4">
				
				<label for="estrela_cinco"><i class="fa"></i></label>
				<input type="radio" id="estrela_cinco" name="estrela" value="5"><br><br>
				
				<input type="submit" value="CONCLUIR" id="concluir" >
			</div>
	</form>
 </div>


 </div>

 


 <footer id="footer">
</footer>
</body>
</html>